<?php include('header.php');?>

<section class="welcome-section">
    <div class="container">
        <h2 class="heading-primary center welcome-section__heading">
            Places to visit
        </h2>
    </div>
</section>

<section class="welcome">
    <div class="container">
        <h2 class="heading-primary center welcome__heading">Welcome to Kashmir</h2>
        <h3 class="center welcome__heading-sub">Explore the paradise on Earth</h3>
        <p class="para center welcome__para">Kashmir is a region in the northern part of the Indian subcontinent. It is often referred to as "Paradise on Earth" due to its breathtaking natural beauty, serene landscapes, and snow-capped mountains.</p>
    </div>
</section>
<main>
    <section id="place" class="welcome-place">
        <div class="container">
            <h2 class="welcome-place__heading heading-primary center">Best Places to Visit in Kashmir</h2>
        </div>
        <!-- Your best places content here -->
    </section>
    <section id="tours" class="tour-place">
        <h2 class="tour-place__heading heading-primary center">Day Tours in Kashmir</h2>
        <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="card tour-place__card">
                    <h3>Day 1: </h3>
                    <img src="images/srinagar.jpeg" class="tour-place__img" alt="Srinagar">
                    <h2>Srinagar Sightseeing</h2>
                    <p class="para">The capital of Kashmir, Srinagar is a beautiful city situated on the banks of the Jhelum River. It is known for its Mughal gardens, houseboats on Dal Lake, and Shankaracharya Hill, which offers panoramic views of the city.</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="card tour-place__card">
                    <h3>Day 2: </h3>
                    <img src="images/gul.jpeg" class="tour-place__img" alt="Gulmarg">
                    <h2>Gulmarg Excursion</h2>
                    <p class="para">A popular hill station, Gulmarg is known for its skiing slopes, gondola rides, and stunning views of the Himalayas. In summer, it is a popular destination for hiking and trekking.</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="card tour-place__card">
                    <h3>Day 3: </h3>
                    <img src="images/son.jpeg" class="tour-place__img" alt="Sonamarg Day">
                    <h2>Sonamarg Day Trip</h2>
                    <p class="para">A meadow town, Sonamarg is known for its glaciers, such as the Thajiwas Glacier. It is a popular destination for trekking and camping.</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="card tour-place__card">
                    <h3>Day 5-6: </h3>
                    <img src="images/leh.jpeg" alt="Leh" class="tour-place__img">
                    <h2>Leh Two Days Trip</h2>
                    <p class="para">The capital of Ladakh, Leh is a high-altitude desert town with a unique Tibetan culture. It is known for its monasteries, gompas, and stunning mountain scenery.</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="card tour-place__card">
                    <h3>Day 7-8: </h3>
                    <img src="images/nubra.jpeg" class="tour-place__img" alt="Nubra Valley">
                    <h2>Nubra Valley Two Days Trip</h2>
                    <p class="para">A high-altitude desert valley, Nubra Valley is known for its sand dunes, Bactrian camels, and Diskit Monastery. It is a popular destination for jeep safaris and trekking.</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="card tour-place__card">
                    <h3>Day 9-10: </h3>
                    <img src="images/pan.jpeg" class="tour-place__img" alt="Pangong Tso">
                    <h2>Pangong Tso Two Days Trip</h2>
                    <p class="para">A high-altitude lake, Pangong Tso is known for its stunning beauty and changing colors. It is a popular destination for photography and wildlife watching.</p>
                </div>
            </div>
        </div>
    </section>
</main>
<?php include('footer.php');?>
