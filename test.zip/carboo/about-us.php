<?php include('header.php');?>

<section class="welcome-section">
    <div class="container">
        <h2 class="heading-primary center welcome-section__heading">
            About Us
        </h2>
    </div>
</section>

<section class="hero">
    <div class="container">
        <h2 class="heading-primary center hero__heading hero__heading--primary">Welcome to Kashmir Car Booking</h2>
        <p class="para center hero__para">Your Gateway to Seamless Travel Experiences</p>
    </div>
</section>
<section class="about-us">
    <div class="container">
        <h2 class="heading-primary center">About Us</h2>
        <p class="para">
            At Kashmir Car Booking, we are dedicated to providing you with the finest car rental services amidst the breathtaking landscapes and serene surroundings of Kashmir. Whether you are a local resident or a traveler exploring this paradise on earth, we are committed to making your journey not just convenient, but truly memorable.
            Our team is passionate about delivering excellence in every aspect of your car rental experience. With a focus on customer satisfaction and safety, we offer an exceptional fleet of vehicles that cater to diverse needs and preferences. From compact cars ideal for solo excursions to spacious SUVs perfect for family adventures, we have an array of options to suit your requirements.
            What sets us apart is our deep understanding of the unique needs of travelers in Kashmir. We take pride in offering well-maintained vehicles that are equipped to navigate the varying terrain and weather conditions of this region, ensuring that your travel is both comfortable and secure.
            As we welcome you to the land of snow-capped peaks, lush valleys, and tranquil lakes, we strive to be more than just a car rental service. Our friendly and knowledgeable team is here to assist you at every step, from selecting the right vehicle to providing insights on the best routes and attractions to explore. With us, you'll find not just a mode of transportation, but trusted companions who are dedicated to enhancing your journey.
        </p>
        <p class="para">
            Booking with us is easy and convenient. Our user-friendly online platform allows you to effortlessly browse through our selection of vehicles, compare prices, and make reservations tailored to your travel plans. With flexible booking options, we aim to accommodate your schedule, whether you need a car for a short local tour or an extended exploration of the region.
            We understand that punctuality and reliability are vital to your travel experience. That's why we ensure that your chosen vehicle is ready for pick-up at the designated location, allowing you to embark on your adventure without any delays.
            Thank you for considering Kashmir Car Booking for your travel needs. We are honored to be part of your Kashmir journey and are eager to serve you with warmth, professionalism, and a commitment to creating unforgettable memories.
        </p>
    </div>
</section>
<!-- cars and best places section -->
<section class="car-card">
    <div class="container">
        <h2 class="heading-primary center card-heading car-card__heading">Featured Cars & Best Places in Kashmir</h2>
        <div class="owl-carousel">
            <!-- Your car card slides go here -->
            <div class="card-slide car-card__slide">
                <div class="card car-card__card">
                    <img src="images/car-2.jpg" class="car-card__img" alt="Car Image">
                    <div class="card-content car-card__content">
                        <h2 class="card-title car-card__title">1Honda Accord</h2>
                        <p class="card-text car-card__text">Sleek and stylish sedan.</p>
                    </div>
                </div>
                <div class="card">
                    <a href="https://en.wikipedia.org/wiki/Dal_Lake"class="car-card__link">
                        <img src="images/dal-lake.webp" alt="Car Image" class="car-card__img">
                        <div class="card-content car-card__content">
                            <h2 class="card-title car-card__title">Dal Lake</h2>
                            <p class="card-text car-card__text">Dal Lake, the jewel of Srinagar, is known for its scenic beauty and houseboats</p>
                    </a>
                    </div>
                </div>
            </div>
            <div class="card-slide car-card__slide">
                <div class="card car-card__card">
                    <img src="images/car-2.jpg" alt="Car Image" class="car-card__img">
                    <div class="card-content car-card__content">
                        <h2 class="card-title car-card__title">3nda Accord</h2>
                        <p class="card-text car-card__text">Sleek and stylish sedan.</p>
                    </div>
                </div>
                <div class="card car-card__card">
                    <a href="https://en.wikipedia.org/wiki/Gulmarg" class="car-card__link">
                        <img src="images/gulmarg.jpg" alt="place Image" class="car-card__img">
                        <div class="card-content car-card__content">
                            <h2 class="card-title car-card__title">Gulmarg</h2>
                            <p class="card-text car-card__text">Gulmarg is a popular hill station known for its skiing and scenic beauty</p>
                    </a>
                    </div>
                </div>
            </div>
            <div class="card-slide car-card__slide">
                <div class="card car-card__card">
                    <img src="images/car-2.jpg" class="car-card__img" alt="Car Image">
                    <div class="card-content car-card__content">
                        <h2 class="card-title car-card__title">5Honda </h2>
                        <p class="card-text car-card__text">Sleek and stylish sedan.</p>
                    </div>
                </div>
                <div class="card car-card__card">
                    <a href="https://in.pinterest.com/pin/453104412510609451/" class="car-card__link">
                        <img src="images/pahalgam.jpeg" alt="Car Image" class="car-card__img">
                        <div class="card-content car-card__content">
                            <h2 class="card-title car-card__title">Pahalgam</h2>
                            <p class="card-text car-card__text">Pahalgam is renowned for its lush greenery, serene rivers, and trekking trails.</p>
                    </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<!-- contact section -->
<section class="contact-about">
    <div class="container">
        <div class="contact-about__box">
            <h2 class="heading-primary center contact-about--primary_heading">Contact Us</h2>
            <div>
                <p class="para contact-about--main_para">If you have any questions or inquiries, feel free to contact us:</p>
                <div>
                    <p class="contact-about__details">
                        Email: <a class="contact-about__link" href="irfanhussainh71548@gmail.com">irfanhussainh71548@gmail.com</a>
                    </p>
                    <p class="contact-about__details">
                        Phone: <a class="contact-about__link" href="tel:+91 9149714811">+91 9149714811</a>
                    </p>
                    <p class="contact-about__details">
                        Address: kashmir srinagar chattabal 190010
                    </p>
                </div>
            </div>
            <div class="contact-about__social-links">
                <a href="#" title="Facebook" class="contact-about__link">
                    <svg class="contact-about__icon contact-about__icon--facebook">
                        <use xlink:href="images/sprite.svg#icon-facebook2"></use>
                    </svg>
                </a>
                <a href="#" title="instagram" class="contact-about__link">
                    <svg class="contact-about__icon contact-about__icon--instagram">
                        <use xlink:href="images/sprite.svg#icon-instagram"></use>
                    </svg>
                </a>
                <a href="#" title="twiiter" class="contact-about__link">
                    <svg class="contact-about__icon contact-about__icon--youtube">
                        <use xlink:href="images/sprite.svg#icon-youtube"></use>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</section>
<section class="booking-about">
    <div class="container">
        <h3 class="center booking-about__heading">Fill out the form below to book a car:</h3>
        <form class="booking-about__form">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group booking-about__form-group">
                        <label for="pickup-date" class="booking-about__label-control">Pickup Date</label>
                        <input type="date" id="pickup-date" name="pickup-date" class="booking-about__input-control" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group booking-about__form-group">
                        <label for="pickup-time" class="booking-about__label-control">Pickup Time</label>
                        <input type="time" id="pickup-time" name="pickup-time" class="booking-about__input-control" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group booking-about__form-group">
                        <label for="return-date" class="booking-about__label-control">Return Date</label>
                        <input type="date" id="return-date" name="return-date" class="booking-about__input-control" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group booking-about__form-group">
                        <label for="person" class="booking-about__label-control">Total Person</label>
                        <input type="number" id="person" nome="person" class="booking-about__input-control" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group booking-about__form-group">
                        <label for="name" class="booking-about__label-control">Your Name</label>
                        <input type="text" id="name" name="name" class="booking-about__input-control" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group booking-about__form-group">
                        <label for="email" class="booking-about__label-control">Your Email</label>
                        <input type="email" id="email" name="email" class="booking-about__input-control" required>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group booking-about__form-control">
                        <label for="phone-no" class="booking-about__label-control">Phone No.</label>
                        <input type="phone-no" class="booking-about__input-control" id="phone-no" name="phone-no" required>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="form-group booking-about__form-group">
                        <button type="submit" class="btn booking-about__btn booking-about__btn--submit">Submit</button>
                    </div>
                </div>
            </div>
            <!-- Your reservation form goes here -->
        </form>
    </div>
</section>
<?php include('footer.php');?>
<!-- slide  cars and best places section  owl script -->
<script>
    $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            loop:true,
            autoplay:true,
            autoplayTimeout:3000, // Auto slide every 5 seconds
            autoplayHoverPause:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                },
                1000:{
                    items:3
                }
            }
        });
    });
</script>
