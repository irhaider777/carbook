
<?php include('header.php');?>

<section class="welcome-section">
    <div class="container">
        <h2 class="heading-primary center welcome-section__heading">
            Booking Form
        </h2>
    </div>
</section>


  <section class="booking-car-form">

    <div class="container">
      <div class="booking-car-form__box">

      <h2 class="heading-primary center booking-car-form--heading">Car Booking Form</h2>

      <form action="form.php" id="bookingForm" onsubmit="submitForm(event)">
        <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
          <label for="name" class="booking-car-form__label-control label-control">Full Name:</label>
          <input type="text" id="name" class="booking-car-form__input-control input-control" name="name" required>

        </div>

        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
          <label for="email" class="booking-car-form__label-control label-control">Email:</label>
          <input type="email" id="email" class="booking-car-form__input-control input-control" name="email" required>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
          
          <label for="phone" class="booking-car-form__label-control label-control">Phone Number:</label>
          <input type="text" id="phone" class="booking-car-form__input-control input-control" name="phone" required>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
          <label for="car" class="booking-car-form__label-control label-control">Selected Car:</label>
          <select name="cars" class="booking-car-form__input-control booking-car-form__select-control" id="cars">
            <option value="volvo">Volvo</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
            <option value="audi">Audi</option>
            <option value="audi">Audi</option>
            <option value="audi">Audi</option>
            <option value="audi">Audi</option>
          </select>          
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
          <label for="price" class="booking-car-form__label-control label-control">Price per day:</label>
          <input type="text" id="price" class="booking-car-form__input-control input-control" name="price" readonly>
      
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
               
          <label for="pickup-date" class="booking-car-form__label-control label-control">Pickup Date:</label>
          <input type="date" id="pickup-date" class="booking-car-form__input-control input-control" name="pickup-date" required>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
          <label for="pickup-time" class="booking-car-form__label-control label-control">Pickup Time:</label>
          <input type="time" id="pickup-time" class="booking-car-form__input-control input-control" name="pickup-time" required>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
          <label for="pickup-location" class="booking-car-form__label-control label-control">Pickup Location:</label>
          <input type="text" id="pickup-location" class="booking-car-form__input-control input-control" name="pickup-location" required>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                   
      
          <label for="dropoff-date" class="booking-car-form__label-control label-control">Return Date:</label>
          <input type="date" id="dropoff-date" class="booking-car-form__input-control input-control" name="dropoff-date" required>
        </div>
        
        <a href="#" class="btn booking-car-form__btn booking-car-form__btn--control" type="submit" value="Submit Booking">SUBMIT NOW</a>
        

      
      
         
    
      
     
      

      
      
        </form>
      </div>
      </div>
    </div>

  </section>

  <?php include('header.php');?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

 

<script>
  // JavaScript for pre-filling car details in the form
  window.onload = function() {
    // Get car and price details from URL parameters
    var urlParams = new URLSearchParams(window.location.search);
    var carName = decodeURIComponent(urlParams.get('car'));
    var price = decodeURIComponent(urlParams.get('price'));

    // Fill in the car and price fields in the form
    document.getElementById('car').value = carName;
    document.getElementById('price').value = price;
  };

  

 
</script>  


