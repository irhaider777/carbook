<?php include('header.php');?>
<main>
    <section class="welcome-home">
      <div class="container">
        <div class="welcome-home__box">
          <h1 class="heading-main">
            <span class="heading-main-primary">Welcome To</span>
            <span class="heading-main-secondary"> Car Booking</span>
          </h1>
          <a href="booking_form.php" class="btn btn--white welcome-home__btn">Book Your Car</a>
        </div>
      </div>
    </section>


    <section class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="title-box">
                        <h2 class="heading-secondary">About us</h2>
                    </div>
                    <p class="para">
                        We the Kashmiri car booking websites offers the best service in the world . We are one of the most trusted organization in the world and hence we Lorem, ipsum dolor sit amet consectetur adipisicing elit. Suscipit est eum quas soluta porro aliquid perspiciatis earum neque harum eligendi? Similique, delectus dolorem eos ea nam quod facilis? Veniam, recusandae!
                    </p>
                    <p class="para">We the Kashmiri car booking websites offers the best service in the world . We are one of the most trusted organization in the world and hence we Lorem, ipsum dolor sit amet consectetur adipisicing elit. Suscipit est eum quas soluta porro aliquid perspiciatis earum neque harum eligendi? Similique, delectus dolorem eos ea nam quod facilis? Veniam, recusandae!</p>
                    <p class="para">We the Kashmiri car booking websites offers the best service in the world . We are one of the most trusted organization in the world and hence we Lorem, ipsum dolor sit amet consectetur adipisicing elit. Suscipit est eum quas soluta porro aliquid perspiciatis earum neque harum eligendi? Similique, delectus dolorem eos ea nam quod facilis? Veniam, recusandae!</p>
                    <a class="btn btn--black">Know More</a>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="about__img-box">
                        <img src="images/about-1.jpeg" alt="Car Image" class="about__img-1 about__img-control" />
                        <!-- <img src="images/about-1.jpeg" alt="Car Image" class="about__img-2 about__img-control">
                            <img src="images/about-1.jpeg" alt="Car Image" class="about__img-3 about__img-control"> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- BLOG SECTION  -->
    <section class="blog-section">
        <div class="container">
            <div class="title-box">
                <h2 class="heading-primary">Blog</h2>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-12">
                    <div class="card">
                        <div class="card-img-top">
                            <img src="images/about-1.jpeg" class="img-fluid" alt="" />
                        </div>
                        <div class="card-body">
                            <div class="card-text">
                                <h5>BEST CAR</h5>
                                <span><i class="far fa-user"></i>Admin <img src="images/blog-icon.png" class="img-fluid" alt="" /> 325 <i class="far fa-eye"></i> 450</span>
                                <p class="para">There are many variations of passages of lorem ipsum available , but the majority have suffered alternation in some form, by injected humour.</p>
                                <a href="">READ MORE</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-12">
                    <div class="card">
                        <div class="card-img-top">
                            <img src="images/about-1.jpeg" class="img-fluid" alt="" />
                        </div>
                        <div class="card-body">
                            <div class="card-text">
                                <h5>BEST SERVICES</h5>
                                <span><i class="far fa-user"></i>Admin <img src="images/blog-icon.png" class="img-fluid" alt="" /> 325 <i class="far fa-eye"></i> 450</span>
                                <p class="para">There are many variations of passages of lorem ipsum available , but the majority have suffered alternation in some form, by injected humour.</p>
                                <a href="">READ MORE</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-12">
                    <div class="card">
                        <div class="card-img-top">
                            <img src="images/about-1.jpeg" class="img-fluid" alt="" />
                        </div>
                        <div class="card-body">
                            <div class="card-text">
                                <h5>5 GOOD REASONS TO TAKE A.....</h5>
                                <span><i class="far fa-user"></i>Admin <img src="images/blog-icon.png" class="img-fluid" alt="" /> 325 <i class="far fa-eye"></i> 450</span>
                                <p class="para">There are many variations of passages of lorem ipsum available , but the majority have suffered alternation in some form, by injected humour.</p>
                                <a href="">READ MORE</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- TESTIMONIAL -->
    <section class="testimonial">
        <div class="container">
            <div class="title-box center">
                <h2 class="heading-primary">Testimonial</h2>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                    <div class="card testimonial__card" >
                        <div class="row">
                            <div class="col-md-4">
                                <img src="images/testimonial-img.jpeg" class="img-fluid rounded-start testimonial__img" alt="User Photo">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body testimonial__card-body">
                                    <h5 class="card-title testimonial__card-title">User Name</h5>
                                    <p class="card-text testimonial__card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                    <p class="card-text testimonial__card-text"><span class="text-muted">2 years ago</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                    <div class="card testimonial__card">
                        <div class="row">
                            <div class="col-md-4">
                                <img src="images/testimonial-img.jpeg" class="img-fluid rounded-start testimonial__img" alt="User Photo">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body testimonial__card-body">
                                    <h5 class="card-title testimonial__card-title">User Name</h5>
                                    <p class="card-text testimonial__card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                    <p class="card-text testimonial__card-text"><span class="text-muted">2 years ago</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                    <div class="card testimonial__card">
                        <div class="row">
                            <div class="col-md-4">
                                <img src="images/testimonial-img.jpeg" class="img-fluid rounded-start testimonial__img" alt="User Photo">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body testimonial__card-body">
                                    <h5 class="card-title testimonial__card-title">User Name</h5>
                                    <p class="card-text testimonial__card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                                    <p class="card-text testimonial__card-text"><span class="text-muted">2 years ago</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTACT US -->
    <section class="contact">
        <div class="container">
            <div class="title-box center">
                <h2 class="heading-primary">Contact Us</h2>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="contact__info">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                            <h4 class="contact__heading">
                                Address
                            </h4>
                            <p class="contact__detail">1st Floor, Dayal Chamber, 3-Way Road Ram Mohan Rai Marg, Hazratganj, Lucknow - 226001, U.P., India</p>
                            <h4 class="contact__heading">
                                Number
                            </h4>
                            <p class="contact__detail">+91 498234392</p>
                            <h4 class="contact__heading">
                                Email
                            </h4>
                            <p class="contact__detail">aaghajaankomaaro@gmail.com</p>
                            <p></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="contact__location">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3447.434339231243!2d78.79605407436458!3d30.22468821001051!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3909a51dccce4e43%3A0xbee78f18b48f6786!2sSrinagar%20Kashmir!5e0!3m2!1sen!2sin!4v1707473191408!5m2!1sen!2sin" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="contact__map"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php include('footer.php');?>
