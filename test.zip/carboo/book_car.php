<?php include('header.php');?>

<section class="welcome-section">
    <div class="container">
        <h2 class="heading-primary center welcome-section__heading">
            Book Your Car
        </h2>
    </div>
</section>

<marquee behavior="alternate" direction="right">Welcome to Kashmir Car Booking</marquee>
<!-- - card  CAR book -->
<div class="cards-background car-book-card">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" class="car-book-card__img" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card car-book-card__card">
                    <img src="bookimages/car-1.jpg" alt="Car Image">
                    <div class="card-content car-book-card__content">
                        <h2 class="card-title car-book-card__title">Toyota Camry</h2>
                        <p class="card-text car-book-card__text">Comfortable sedan for family trips.</p>
                        <p class="card-text rs car-book-card__rupees">Price per day: $50</p>
                        <button class="card-btn-book car-book-card__btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- weather section -->
<a class="weatherwidget-io" href="https://forecast7.com/en/34d0874d80/srinagar/" data-label_1="KASHMIR" data-label_2="WEATHER" data-font="Play" data-icons="Climacons Animated" data-mode="Forecast" data-theme="candy" >KASHMIR WEATHER</a>
<hr>
<!-- Footer part -->
<?php include('footer.php');?>
<!-- booking form page script -->
<script>
    // weather section 
    !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
    // END
    
    function openBookingForm(carName, price) {
    // Encode car name and price in URL parameters
    var encodedCarName = encodeURIComponent(carName);
    var encodedPrice = encodeURIComponent(price);
    // Redirect to booking form page with car details in URL
    window.location.href = 'booking_form.html?car=' + encodedCarName + '&price=' + encodedPrice;
    }
</script>
