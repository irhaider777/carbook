<?php include('header.php');?>

<section class="welcome-section">
    <div class="container">
        <h2 class="heading-primary center welcome-section__heading">
            Pricing
        </h2>
    </div>
</section>

  <section class="pricing-about">
    <div class="container">
      <div class="pricing-abpricing-box">

        <h2 class="heading-primary center">welcom to kashmir car booking</h2>
        <p class="para">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aspernatur, deleniti a. Ea autem laboriosam modi expedita beatae culpa soluta esse ipsam voluptas corrupti quae cupiditate eligendi voluptatum consequatur voluptatibus, alias itaque quia provident, minus nam qui. Eligendi consequatur laboriosam ex, autem facilis ipsam architecto officia pariatur quis facere, beatae impedit molestias illo labore quia repudiandae repellendus deserunt, sed doloribus itaque voluptatibus quae voluptatum iste. Aperiam quisquam repudiandae veritatis fugiat. Blanditiis eligendi libero, est suscipit ipsa modi enim maxime repellendus. Debitis harum illum temporibus voluptatem vel aut laborum dolore magni atque omnis consectetur, sapiente tempore minima repudiandae nostrum maiores quas amet?</p>
      </div>
        
      </div>
  </section>

  <section class="places">

    <div class="container">
        <h2 class="heading-primary center">KASHMIR BEST PLACES</h2>
        <div class="places__video">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12">

              <video width="350" height="500" autoplay loop controls muted autoplay playsinline style="pointer-events: none;">
                  <source src="cars images/video.mp4" type="video/mp4">
                  
                  Your browser does not support the video tag.
                </video>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12">
              <video width="350" height="500" autoplay loop controls muted autoplay playsinline style="pointer-events: none;">
                  <source src="cars images/video.mp4" type="video/mp4">
                  
                  Your browser does not support the video tag.
                </video>

            </div>

          </div>

          
          <a href="places.php" class="btn places__btn place__btn--more-places margin-t-m">See More Places</a>
          
          
        </div>
    </div>
  </section>

  <section class="charges">
    <div class="container">
      <h2 class="heading-primary center">Car Charges Per day</h2>
      <caption class="charges__caption">
          Srinagar to Srinagar (pickup & drop From Srinagar)
        </caption>

        <div class="row">
          <div class="col-lg-6 col-md-6 col-6">
            <ul class="charger__car-detail charges__list">
              <li class="charges__car-model charges__car-model--heading">Car Model</li>
              <li class="charges__car-model">Swift Disire / Etios</li>
              <li class="charges__car-model">Crysta</li>
              <li class="charges__car-model">Tampo Travel</li>
              <li class="charges__car-model">Inovia</li>
              <li class="charges__car-model">Urbania</li>
              <li class="charges__car-model">27 Video Coach Bus</li>
          </ul>
          </div>
          <div class="col-lg-6 col-md-6 col-6">
            <ul class="charges__car-price charges__list">
              <li class="charges__price charges__price--heading">Price Per Day</li>
              <li class="charges__price">&#8377; 2399</li>
              <li class="charges__price">&#8377; 3499</li>
              <li class="charges__price">&#8377; 4499</li>
              <li class="charges__price">&#8377; 2999</li>
              <li class="charges__price">&#8377; 7999</li>
              <li class="charges__price">&#8377; 7999</li>
            </ul>
          </div>
        </div>

  </section>



  <section class="car-prices">
    <div class="container">
      <h1 class="heading-primary center">Car Booking Prices</h1>

      <div class="row">
        <div class="col-lg-6 col-md-6 col-6">
          <ul class="car-prices__car-detail charges__list">
            <li class="car-prices__car-model car-prices__car-model--heading">INCLUSIONS</li>
            <li class="car-prices__car-model">FUEL , TOLLS , PARKING , HEARTING</li>
            <li class="car-prices__car-model">Throunghout the way sightseeing</li>
            <li class="car-prices__car-model">Dirver cum guide</li>
            <li class="car-prices__car-model">Driver's food and accommodation</li>
            <li class="car-prices__car-model">Guidence and assistance throughout the tour 24/7</li>
            <li class="car-prices__car-model">Guidence and assistance throughout the tour 24/7</li>
        </ul>
        </div>
        <div class="col-lg-6 col-md-6 col-6">
          <ul class="car-prices__car-price charges__list">
            <li class="car-prices__price car-prices__price--heading">EXCLUSIONS</li>
            <li class="car-prices__price">Pahalgam/ Gulmarg/ Sonmarg/ till hostel or main destination parking</li>
            <li class="car-prices__price">Snow jeeps required for Tangmarg-Gulmarg & Gund-Sonamarg in heavy snow conditions</li>
            <li class="car-prices__price">Optional Tours like Aru , Betaab Valleys, Zerp-point, Drass, Drung, Not allowed</li>
            <li class="car-prices__price">Snow jeeps required for Tangmarg-Gulmarg & Gund-Sonamarg in heavy snow conditions</li>
            <li class="car-prices__price">Road blockage,Govt.orders,flight delay etc NO responsibility & No rebates.</li>
            <li class="car-prices__price">Union Transport, Jammu service, AC charges 250/day & Anything not mentioned in Inclusions</li>
          </ul>
        </div>
      </div>

    </div>
  </section>
  


  <section class="car-booking-card">
    <div class="container">
      <h2 class="heading-primary center">Book Your Car</h2>

      <div class="row">

        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="card car-booking-card__card">
            <img src="bookimages/car-1.jpg" alt="Car Image">
            <div class="card-content car-booking-card__content">
              <h2 class="card-title car-booking-card__title">Toyota Camry</h2>
              <p class="card-text car-booking-card__text">Comfortable sedan for family trips.</p>
              <p class="card-text car-booking-card__rupee">Price per day: $50</p>
              <button class="card-btn-book car-booking-card__btn btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="card car-booking-card__card">
            <img src="bookimages/car-1.jpg" alt="Car Image">
            <div class="card-content car-booking-card__content">
              <h2 class="card-title car-booking-card__title">Toyota Camry</h2>
              <p class="card-text car-booking-card__text">Comfortable sedan for family trips.</p>
              <p class="card-text car-booking-card__rupee">Price per day: $50</p>
              <button class="card-btn-book car-booking-card__btn btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="card car-booking-card__card">
            <img src="bookimages/car-1.jpg" alt="Car Image">
            <div class="card-content car-booking-card__content">
              <h2 class="card-title car-booking-card__title">Toyota Camry</h2>
              <p class="card-text car-booking-card__text">Comfortable sedan for family trips.</p>
              <p class="card-text car-booking-card__rupee">Price per day: $50</p>
              <button class="card-btn-book car-booking-card__btn btn" onclick="openBookingForm('Toyota Camry', 50)">Book Now</button>
            </div>
          </div>
        </div>
  </div>
</div>
  </section>
  <?php include('footer.php');?>

