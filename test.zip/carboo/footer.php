
<footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-12">
          <div class="footer__logo">
            <img src="images/logo.png" class="footer__logo--img" alt="" />
            <p class="para">Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam maxime omnis saepe ratione distinctio ipsum.</p>

          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-12">
          <div class="footer__head">Information</div>
          <ul>
            <li class="footer__list-item"><a href="#" class="footer__list-link">About</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">Service</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">Term and Conditios</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">Best price Guarantee</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">Privacy &amp; Cookies policy</a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-12">
          <div class="footer__head">Customer Support</div>
          <ul>
            <li class="footer__list-item"><a href="#" class="footer__list-link">FAQ</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">Payment Option</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">Booking Trip</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">How it work</a></li>
            <li class="footer__list-item"><a href="#" class="footer__list-link">Contact Us</a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-12">
          <div class="footer__head">HAve a question</div>
          <div class="block-23 mb-3">
            <ul>
                <li><span class="icon icon-map-marker"></span><span class="text footer__list-link">Chattabal Srimagar, patli pora payeem, Srinagar kashmir</span></li>
                <li class="footer__list-item"><a href="#" class="footer__list-link"><span class="icon icon-phone"></span><span class="text">+91 9149714811</span></a></li>
                <li class="footer__list-item"><a href="#" class="footer__list-link"><span class="icon icon-envelope"></span><span class="text">info@kashbook.com</span></a></li>
            </ul>
        </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Will be at the bottom among all js file -->
  <script src="js/script.js"></script>

</body>
</html>