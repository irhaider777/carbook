<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
    <title>Car Booking</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>

    <header class="header">
      <!-- Top Navbar -->   
    <div class="nav-top">
      <nav class="navbar navbar-expand-sm">
        <div class="container">
          
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-top__list">
              
              <li class="nav-item nav-top__item">
                <a class="nav-link nav-top__link" href=""> <span> 
                  <svg class="nav-top__phone-icon nav-top__icon" >
                  <use xlink:href="images/sprite.svg#icon-phone"></use>
                </svg>:  +91 8537398765</a> </span>
              </li>
              <li class="nav-item nav-top__item">
                <a class="nav-link nav-top__link" href="#">
                   <span> 
                    <svg class="nav-top__phone-envelop nav-top__icon" >
                  <use xlink:href="images/sprite.svg#icon-envelop"></use>
                </svg>:  email@email.com</a> </span>
              </li>
            </ul>
            
          </div>
        </div>
      </nav>

    </div>

      <div class="nav-bottom">

      <!-- Bottom Navbar -->
      <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
        <a class="navbar-brand nav-bottom__logo" href="#"><img src="images/logo.png" class="nav-bottom__logo-img" alt="logo" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon">
            <svg class="nav-bottom__menu nav-bottom__icon" >
            <use xlink:href="images/sprite.svg#icon-menu"></use>
          </svg>
         </span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav nav-bottom__list">
            <li class="nav-item nav-bottom__item">
              <a class="nav-link nav-bottom__link active" aria-current="page" href="index.php">Home</a>
            </li>
            <li class="nav-item nav-bottom__item">
              <a class="nav-link nav-bottom__link" href="about-us.php">about us</a>
            </li>
            <li class="nav-item nav-bottom__item">
              <a class="nav-link nav-bottom__link" href="#">blogs</a>
            </li>
            <li class="nav-item nav-bottom__item ">
              <a class="nav-link nav-bottom__link" href="Pricing.php">Pricing</a>
            </li>
            <li class="nav-item nav-bottom__item">
              <a class="nav-link nav-bottom__link" href="#">Testimonial</a>
            </li>
            <li class="nav-item nav-bottom__item">
              <a class="nav-link nav-bottom__link" href="Contact_us.php">Contact us</a>
            </li>
            <li class="nav-item nav-bottom__item">
              <a class="nav-link nav-bottom__link" href="book_car.php">Book Car</a>
            </li>
            
            
          </ul>
          
        </div>
      </div>
    </nav>
  </div>

 
  

</header>