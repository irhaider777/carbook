

<?php include('header.php');?>

<section class="welcome-section">
    <div class="container">
        <h2 class="heading-primary center welcome-section__heading">
            Contact Us
        </h2>
    </div>
</section>

    <section class="contact-section">
        <div class="container">
            <div class="contact-section__contact-box">
            
            <h2 class="heading-primary center">
                Contact Us
            </h2>

            <div class="row">
                <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                    <div class="contact-section__form">
                        <form action="#" method="post">
                            
                            <!-- <div class="row"></div> -->
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <label class="label-control contact-section__label-control contact-section--label-control" for="name">Name:</label>
                                <input class="form-control contact-section__form-control contact-section--form-control" type="text" id="name" name="name">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <label class="label-control contact-section__label-control contact-section--label-control" for="email">Email:</label>
                                <input class="form-control contact-section__form-control contact-section--form-control" type="email" id="email" name="email">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <label for="message" class="label-control contact-section__label-control contact-section--label-control">
                                    Enter Your Query:
                                </label>
                                <textarea class="textarea-control contact-section__textarea-control contact-section--textarea-control" id="message" name="message">
                                    
                                </textarea>
                            </div>
                            <a class="contact-section__btn btn btn--blue">Submit</a>
                        </form>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="contact-section__social-media">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                            <a href="https://www.whatsapp.com" class="contact-section__link" target="_blank">
                                <svg class="contact-section__icon  contact-section__icon--facebook">
                                    <use xlink:href="images/sprite.svg#icon-facebook2"></use>
                                </svg>
                            </a>
                            
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                            
                            <a href="https://www.instagram.com" class="contact-section__link" target="_blank">
                                <svg class="contact-section__icon contact-section__icon--instagram">
                                    <use xlink:href="images/sprite.svg#icon-instagram"></use>
                                </svg>
                            </a>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                            
                            <a href="https://www.facebook.com" class="contact-section__link" target="_blank">
                                <svg class="contact-section__icon contact-section__icon--whatsapp">
                                    <use xlink:href="images/sprite.svg#icon-whatsapp"></use>
                                </svg>
                            </a>
                        </div>
                    </div>  

                    
                </div>
            </div>
        </div>
    </div>
    </section>
    
    <?php include('footer.php');?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

